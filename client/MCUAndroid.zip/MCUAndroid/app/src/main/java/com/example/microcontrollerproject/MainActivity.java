package com.example.microcontrollerproject;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketAddress;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {

    // UI 요소 선언
    private EditText ipAddressEditText, portEditText;
    private Button connectButton, controlModeButton, exitButton;
    private static Socket socket; // 소켓 객체
    private String ipAddress;
    private int port;
    private final ExecutorService executorService = Executors.newFixedThreadPool(4); // ExecutorService
    private static OutputStream outputStream;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main); // activity_main 레이아웃 설정

        // 툴바 설정
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("마이크로컨트롤러 프로젝트 2조");

        // 뷰 객체 초기화
        ipAddressEditText = findViewById(R.id.ip_address);
        portEditText = findViewById(R.id.port);
        connectButton = findViewById(R.id.connect_button);
        controlModeButton = findViewById(R.id.control_mode_button);
        exitButton = findViewById(R.id.exit_button);

        // 서버 연결 버튼 클릭 이벤트 리스너 설정
        connectButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // IP 주소와 포트 번호를 입력받음
                ipAddress = ipAddressEditText.getText().toString();
                String portString = portEditText.getText().toString();

                // IP 주소와 포트 번호가 비어 있는지 확인
                if (ipAddress.isEmpty() || portString.isEmpty()) {
                    Toast.makeText(MainActivity.this, "IP 주소와 포트를 입력하세요", Toast.LENGTH_SHORT).show();
                } else {
                    try {
                        // 포트 번호를 정수로 변환
                        port = Integer.parseInt(portString);
                        // 서버 연결 작업 실행
                        ConnectServer();
                    } catch (NumberFormatException e) {
                        Toast.makeText(MainActivity.this, "올바른 포트 번호를 입력하세요", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        // 조종 모드 버튼 클릭 이벤트 리스너 설정
        controlModeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // ControlModeActivity로 이동
                Intent intent = new Intent(MainActivity.this, ControlModeActivity.class);
                startActivity(intent);
            }
        });

        // 종료 버튼 클릭 이벤트 리스너 설정
        exitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 액티비티 종료
                finish();
            }
        });
    }


    // 서버 연결 작업을 위한 메소드
    private void ConnectServer() {
        executorService.execute(()->{
            boolean success= false;
            try {
                // 소켓 객체 생성 및 서버 연결 시도
                socket = new Socket();
                SocketAddress socketAddress = new InetSocketAddress(ipAddress, port);
                socket.connect(socketAddress, 5000); // 5초 타임아웃 설정
                success =true;
            } catch (IOException e) {
                e.printStackTrace();

            }

            boolean finalSuccess = success;
            runOnUiThread(() -> {
                if (finalSuccess) {
                    Toast.makeText(MainActivity.this, "서버에 연결되었습니다", Toast.LENGTH_SHORT).show();
                    sendClient();
                } else {
                    Toast.makeText(MainActivity.this, "서버 연결에 실패했습니다", Toast.LENGTH_SHORT).show();
                }
            });
        });
    }


    public void sendClient() {
        executorService.execute(()->{
            boolean success = false;
            try{
                InputStream inputStream = socket.getInputStream();
                byte[] bytes = new byte[128];
                outputStream = socket.getOutputStream();
                outputStream.write("client".getBytes());
                int bytesRead = inputStream.read(bytes);
                if (bytesRead != -1) {
                    String receivedMessage = new String(bytes, 0, bytesRead).trim();
                    if ("Client".equals(receivedMessage)) {
                        success = true;
                    }
                }
            } catch (Exception e){
                e.printStackTrace();
            }

            boolean finalSuccess = success;
            runOnUiThread(() -> {
                if (finalSuccess) {
                    Toast.makeText(MainActivity.this, "모드 설정에 성공했습니다.", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(MainActivity.this, "모드 설정에 실패했습니다", Toast.LENGTH_SHORT).show();
                }
            });
        });
    }

    // 소켓 객체 반환 메서드
    public static Socket getSocket() {
        return socket;
    }
    public static OutputStream getOutputStream() {return outputStream;}

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // 액티비티가 파괴될 때 소켓을 닫음
        if (socket != null) {
            try {
                socket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
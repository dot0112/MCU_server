package com.example.microcontrollerproject;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import java.util.concurrent.Executors;
import java.util.concurrent.ExecutorService;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.widget.Button;
import android.widget.ImageView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;

public class ControlModeActivity extends AppCompatActivity {

    private static final String TAG = "ControlModeActivity"; // 로그 태그
    private ImageView imageView; // 이미지 뷰 객체
    private Button buttonW, buttonS, buttonA, buttonD; // 버튼 객체
    private Socket socket; // 소켓 객체
    private OutputStream outputStream; // 출력 스트림 객체
    private final Handler handler = new Handler(); // UI 업데이트를 위한 핸들러
    private static final int UPDATE_INTERVAL = 50; // 이미지 업데이트 간격 (밀리초 단위)
    private final ExecutorService executorService = Executors.newFixedThreadPool(4); // ExecutorService

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_control_mode); // XML 레이아웃 파일 설정

        // 툴바 설정
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("마이크로컨트롤러 프로젝트 2조");

        // 이미지 뷰와 버튼 객체 초기화
        imageView = findViewById(R.id.imageView);
        buttonW = findViewById(R.id.button_w);
        buttonS = findViewById(R.id.button_s);
        buttonA = findViewById(R.id.button_a);
        buttonD = findViewById(R.id.button_d);

        // MainActivity에서 소켓 객체를 전달받아 사용
        socket = MainActivity.getSocket(); // static 메서드를 통해 소켓 객체 가져오기
        outputStream = MainActivity.getOutputStream(); // static 메서드를 통해 출력 흐름 가져오기

        // 버튼 클릭 이벤트 설정
        buttonW.setOnClickListener(v -> sendCommand('w'));
        buttonS.setOnClickListener(v -> sendCommand('s'));
        buttonA.setOnClickListener(v -> sendCommand('a'));
        buttonD.setOnClickListener(v -> sendCommand('d'));

        // 이미지 업데이트 시작
        startImageUpdate();
    }

    // 이미지 업데이트 함수
    private void startImageUpdate() {
        new Thread(() -> {
            try (InputStream inputStream = socket.getInputStream();
                 ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream()) {

                byte[] buffer = new byte[4096]; // 이미지 데이터를 읽어올 버퍼
                boolean recv = false;
                int bytesRead; // 읽어온 바이트 수
                while(true) {
                    outputStream.write('p');
                    while (true) {
                        bytesRead = inputStream.read(buffer); // 입력 스트림에서 데이터 읽기
                        if (bytesRead > 0) {
                            byteArrayOutputStream.write(buffer, 0, bytesRead); // 버퍼에 데이터 쓰기
                            byte[] data = byteArrayOutputStream.toByteArray();
                            int start = -1;
                            int end = -1;
                            // JPEG 파일의 시작과 끝 위치 찾기
                            for (int i = 0; i < data.length - 1; i++) {
                                if (data[i] == (byte) 0xFF && data[i + 1] == (byte) 0xD8) {
                                    start = i;
                                }
                                if (data[i] == (byte) 0xFF && data[i + 1] == (byte) 0xD9) {
                                    end = i + 2;
                                }
                                // JPEG 파일이 완전히 읽혔는지 확인
                                if (start != -1 && end != -1 && end > start) {
                                    byte[] frameData = new byte[end - start];
                                    System.arraycopy(data, start, frameData, 0, frameData.length);
                                    // 이미지 데이터를 비트맵으로 디코딩
                                    final Bitmap bitmap = BitmapFactory.decodeByteArray(frameData, 0, frameData.length);
                                    // UI 스레드에서 이미지 뷰 업데이트
                                    handler.post(() -> imageView.setImageBitmap(bitmap));
                                    byteArrayOutputStream.reset(); // 버퍼 초기화
                                    byteArrayOutputStream.write(data, end, data.length - end); // 남은 데이터 버퍼에 쓰기
                                    Thread.sleep(UPDATE_INTERVAL); // 업데이트 간격만큼 대기
                                    recv = true;
                                    break;
                                }
                            }
                            if(recv) {
                                recv = false;
                                break;
                            }
                        }
                    }
                }
            } catch (Exception e) {
                Log.e(TAG, "이미지 업데이트 중 오류 발생", e); // 오류 발생 시 로그 출력
            }
        }).start();
    }

    // ExecutorService를 사용하여 서버에 명령을 보내는 메서드
    private void sendCommand(char command) {
        executorService.execute(() -> {
            if (outputStream != null) {
                try {
                    outputStream.write((byte) command); // 명령어를 출력 스트림에 쓰기
                } catch (IOException e) {
                    Log.e(TAG, "명령 전송 중 오류 발생", e);
                }
            } else {
                Log.e(TAG, "출력 스트림이 null입니다.");
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (socket != null) {
            try {
                socket.close(); // 액티비티 종료 시 소켓 닫기
            } catch (IOException e) {
                e.printStackTrace(); // 오류 발생 시 스택 트레이스 출력
            }
        }
    }
}
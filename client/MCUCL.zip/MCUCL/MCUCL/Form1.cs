﻿using System;
using System.Drawing;
using System.IO;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ClientFormApp
{
	public partial class Form1 : Form
	{
		private TcpClient client;
		private NetworkStream stream;
		private CancellationTokenSource cancellationTokenSource;

		public Form1()
		{
			InitializeComponent();
		}

		private void Form1_Load(object sender, EventArgs e)
		{

			this.KeyPreview = true;
			this.KeyDown += new KeyEventHandler(Form1_KeyDown);
		}

		private void buttonConnect_Click(object sender, EventArgs e)
		{
			ConnectToServer();
		}

		private async void ConnectToServer()
		{
			string ipAddress = textBoxIPAddress.Text;
			int port = int.Parse(textBoxPort.Text);

			try
			{
				client = new TcpClient(ipAddress, port);
				stream = client.GetStream();
				await SendInitialMessage();
				cancellationTokenSource = new CancellationTokenSource();
				await StartReading(cancellationTokenSource.Token);
			}
			catch (Exception ex)
			{
				AddErrorMessage($"Main Error: {ex.Message}");
			}
		}

		private async Task SendInitialMessage()
		{
			byte[] buffer = Encoding.UTF8.GetBytes("client");
			await stream.WriteAsync(buffer, 0, buffer.Length);

			buffer = new byte[1024];
			int bytesRead = await stream.ReadAsync(buffer, 0, buffer.Length);
			if (Encoding.ASCII.GetString(buffer, 0, bytesRead) != "Client")
			{
				throw new Exception("can't connect");
			}
		}

		private async Task StartReading(CancellationToken cancellationToken)
		{
			byte[] buffer = new byte[1024];
			int bytesRead;
			MemoryStream ms = new MemoryStream();

			try
			{
				while (!cancellationToken.IsCancellationRequested)
				{
					await SendMessage("p");
					while (!cancellationToken.IsCancellationRequested && (bytesRead = await stream.ReadAsync(buffer, 0, buffer.Length)) > 0)
					{
						ms.Write(buffer, 0, bytesRead);
						if (ProcessReceivedData(ms))
							break;
					}
				}
			}
			catch (OperationCanceledException)
			{
			}
			catch (Exception ex)
			{
				AddErrorMessage($"StartReading Error: {ex.StackTrace}");
			}
			finally
			{
				stream?.Close();
				client?.Close();
			}
		}

		private bool ProcessReceivedData(MemoryStream ms)
		{
			byte[] data = ms.ToArray();
			int start = -1;
			int end = -1;
			bool saved = false;

			for (int i = 0; i < data.Length - 1; i++)
			{
				if (data[i] == 0xFF && data[i + 1] == 0xD8) { start = i; }
				if (data[i] == 0xFF && data[i + 1] == 0xD9) { end = i + 2; }
				if (start != -1 && end != -1 && end > start)
				{
					byte[] frameData = new byte[end - start];
					Array.Copy(data, start, frameData, 0, frameData.Length);
					using (MemoryStream mest = new MemoryStream(frameData))
					{
						pictureBoxCamera.Image = Image.FromStream(mest);
					}
					ms.SetLength(0);
					ms.Write(data, end, data.Length - end);
					saved = true;
					break;
				}
			}
			return saved;
		}

		private async Task SendMessage(string message)
		{
			byte[] buffer = Encoding.UTF8.GetBytes(message);
			await stream.WriteAsync(buffer, 0, buffer.Length);
		}

		private void buttonW_Click(object sender, EventArgs e)
		{
			SendMessage("w");
		}

		private void buttonA_Click(object sender, EventArgs e)
		{
			SendMessage("a");
		}

		private void buttonS_Click(object sender, EventArgs e)
		{
			SendMessage("s");
		}

		private void buttonD_Click(object sender, EventArgs e)
		{
			SendMessage("d");
		}

		private async void Form1_FormClosing(object sender, FormClosingEventArgs e)
		{
			await DisconnectFromServer();
		}

		private async Task DisconnectFromServer()
		{
			if (cancellationTokenSource != null)
			{
				cancellationTokenSource.Cancel();
				cancellationTokenSource.Dispose();
				cancellationTokenSource = null;
			}

			if (stream != null)
			{
				stream.Close();
				stream = null;
			}

			if (client != null)
			{
				client.Close();
				client = null;
			}
			pictureBoxCamera.Image = null;
		}

		private async void buttonDisconnect_Click(object sender, EventArgs e)
		{
			await DisconnectFromServer();
		}

		private void Form1_KeyDown(object sender, KeyEventArgs e)
		{
			switch (e.KeyCode)
			{
				case Keys.W:
					SendMessage("w");
					break;
				case Keys.A:
					SendMessage("a");
					break;
				case Keys.S:
					SendMessage("s");
					break;
				case Keys.D:
					SendMessage("d");
					break;
			}
		}

		private void AddErrorMessage(string message)
		{
			MessageBox.Show(message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
		}
	}
}

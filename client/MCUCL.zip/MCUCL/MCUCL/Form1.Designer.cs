﻿namespace ClientFormApp
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.PictureBox pictureBoxCamera;
        private System.Windows.Forms.Button buttonW;
        private System.Windows.Forms.Button buttonA;
        private System.Windows.Forms.Button buttonS;
        private System.Windows.Forms.Button buttonD;
        private System.Windows.Forms.TextBox textBoxIPAddress;
        private System.Windows.Forms.TextBox textBoxPort;
        private System.Windows.Forms.Button buttonConnect;
        private System.Windows.Forms.Button buttonDisconnect;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
			this.pictureBoxCamera = new System.Windows.Forms.PictureBox();
			this.buttonW = new System.Windows.Forms.Button();
			this.buttonA = new System.Windows.Forms.Button();
			this.buttonS = new System.Windows.Forms.Button();
			this.buttonD = new System.Windows.Forms.Button();
			this.textBoxIPAddress = new System.Windows.Forms.TextBox();
			this.textBoxPort = new System.Windows.Forms.TextBox();
			this.buttonConnect = new System.Windows.Forms.Button();
			this.buttonDisconnect = new System.Windows.Forms.Button();
			((System.ComponentModel.ISupportInitialize)(this.pictureBoxCamera)).BeginInit();
			this.SuspendLayout();
			// 
			// pictureBoxCamera
			// 
			this.pictureBoxCamera.Location = new System.Drawing.Point(12, 12);
			this.pictureBoxCamera.Name = "pictureBoxCamera";
			this.pictureBoxCamera.Size = new System.Drawing.Size(776, 350);
			this.pictureBoxCamera.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
			this.pictureBoxCamera.TabIndex = 0;
			this.pictureBoxCamera.TabStop = false;
			// 
			// buttonW
			// 
			this.buttonW.Location = new System.Drawing.Point(365, 368);
			this.buttonW.Name = "buttonW";
			this.buttonW.Size = new System.Drawing.Size(75, 23);
			this.buttonW.TabIndex = 1;
			this.buttonW.Text = "W";
			this.buttonW.UseVisualStyleBackColor = true;
			this.buttonW.Click += new System.EventHandler(this.buttonW_Click);
			// 
			// buttonA
			// 
			this.buttonA.Location = new System.Drawing.Point(284, 397);
			this.buttonA.Name = "buttonA";
			this.buttonA.Size = new System.Drawing.Size(75, 23);
			this.buttonA.TabIndex = 2;
			this.buttonA.Text = "A";
			this.buttonA.UseVisualStyleBackColor = true;
			this.buttonA.Click += new System.EventHandler(this.buttonA_Click);
			// 
			// buttonS
			// 
			this.buttonS.Location = new System.Drawing.Point(365, 397);
			this.buttonS.Name = "buttonS";
			this.buttonS.Size = new System.Drawing.Size(75, 23);
			this.buttonS.TabIndex = 3;
			this.buttonS.Text = "S";
			this.buttonS.UseVisualStyleBackColor = true;
			this.buttonS.Click += new System.EventHandler(this.buttonS_Click);
			// 
			// buttonD
			// 
			this.buttonD.Location = new System.Drawing.Point(446, 397);
			this.buttonD.Name = "buttonD";
			this.buttonD.Size = new System.Drawing.Size(75, 23);
			this.buttonD.TabIndex = 4;
			this.buttonD.Text = "D";
			this.buttonD.UseVisualStyleBackColor = true;
			this.buttonD.Click += new System.EventHandler(this.buttonD_Click);
			// 
			// textBoxIPAddress
			// 
			this.textBoxIPAddress.Location = new System.Drawing.Point(12, 368);
			this.textBoxIPAddress.Name = "textBoxIPAddress";
			this.textBoxIPAddress.Size = new System.Drawing.Size(100, 21);
			this.textBoxIPAddress.TabIndex = 5;
			this.textBoxIPAddress.Text = "3.34.222.218";
			// 
			// textBoxPort
			// 
			this.textBoxPort.Location = new System.Drawing.Point(118, 368);
			this.textBoxPort.Name = "textBoxPort";
			this.textBoxPort.Size = new System.Drawing.Size(100, 21);
			this.textBoxPort.TabIndex = 6;
			this.textBoxPort.Text = "80";
			// 
			// buttonConnect
			// 
			this.buttonConnect.Location = new System.Drawing.Point(224, 368);
			this.buttonConnect.Name = "buttonConnect";
			this.buttonConnect.Size = new System.Drawing.Size(75, 23);
			this.buttonConnect.TabIndex = 7;
			this.buttonConnect.Text = "Connect";
			this.buttonConnect.UseVisualStyleBackColor = true;
			this.buttonConnect.Click += new System.EventHandler(this.buttonConnect_Click);
			// 
			// buttonDisconnect
			// 
			this.buttonDisconnect.Location = new System.Drawing.Point(224, 397);
			this.buttonDisconnect.Name = "buttonDisconnect";
			this.buttonDisconnect.Size = new System.Drawing.Size(75, 23);
			this.buttonDisconnect.TabIndex = 8;
			this.buttonDisconnect.Text = "Disconnect";
			this.buttonDisconnect.UseVisualStyleBackColor = true;
			this.buttonDisconnect.Click += new System.EventHandler(this.buttonDisconnect_Click);
			// 
			// Form1
			// 
			this.ClientSize = new System.Drawing.Size(800, 450);
			this.Controls.Add(this.buttonDisconnect);
			this.Controls.Add(this.buttonConnect);
			this.Controls.Add(this.textBoxPort);
			this.Controls.Add(this.textBoxIPAddress);
			this.Controls.Add(this.buttonD);
			this.Controls.Add(this.buttonS);
			this.Controls.Add(this.buttonA);
			this.Controls.Add(this.buttonW);
			this.Controls.Add(this.pictureBoxCamera);
			this.Name = "Form1";
			this.Text = "Client";
			this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
			this.Load += new System.EventHandler(this.Form1_Load);
			((System.ComponentModel.ISupportInitialize)(this.pictureBoxCamera)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();

        }
    }
}
